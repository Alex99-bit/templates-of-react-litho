const TextSliderData01 = [
    {
        img: "https://via.placeholder.com/1200x702",
        subtitle: "Romantic",
        title: "Romantic getaways around the world",
        content: "Lorem ipsum dolor sit consectetur adipiscing eiusmod tempor incididunt labore dolore magna ut enim.",
        buttonTitle: "Explore vacation",
        buttonLink: "#"
    },
    {
        img: "https://via.placeholder.com/1200x702",
        subtitle: "Family",
        title: "Explore incredible deals on family tours",
        content: "Lorem ipsum dolor sit consectetur adipiscing eiusmod tempor incididunt labore dolore magna ut enim.",
        buttonTitle: "Explore vacation",
        buttonLink: "#"
    },
    {
        img: "https://via.placeholder.com/1200x702",
        subtitle: "Wildlife",
        title: "Explore a wide range of wildlife packages",
        content: "Lorem ipsum dolor sit consectetur adipiscing eiusmod tempor incididunt labore dolore magna ut enim.",
        buttonTitle: "Explore vacation",
        buttonLink: "#"
    }
]


const TextSliderData02 = [
    {
        img: "https://via.placeholder.com/1050x614",
        title: 'Business',
        subtitle: ' transformation',
        content: 'Lorem ipsum dolor consectetur adipiscing mod tempor incididunt labore dolore magna ut veniam.',
        buttonTitle: "Learn more",
        buttonLink: "/page/our-services"
    },
    {
        img: "https://via.placeholder.com/1050x614",
        title: "Strategic",
        subtitle: "communication",
        content: "Lorem ipsum dolor consectetur adipiscing mod tempor incididunt labore dolore magna ut veniam.",
        buttonTitle: "Learn more",
        buttonLink: "/page/our-services"
    },
    {
        img: "https://via.placeholder.com/1920x950",
        title: "Competitors",
        subtitle: " research",
        content: "Lorem ipsum dolor consectetur adipiscing mod tempor incididunt labore dolore magna ut veniam.",
        buttonTitle: "Learn more",
        buttonLink: "/page/our-services"
    },
    {
        img: "https://via.placeholder.com/1050x614",
        title: "Consumer",
        subtitle: " research",
        content: "Lorem ipsum dolor consectetur adipiscing mod tempor incididunt labore dolore magna ut veniam.",
        buttonTitle: "Learn more",
        buttonLink: "/page/our-services"
    },
]


const TextSliderData03 = [
    {
        img: "https://via.placeholder.com/554x643",
        icon: "line-icon-Cookies",
        title: "Food delivery",
        content: "Lorem ipsum dolor amet consectetur adipiscing"
    },
    {
        img: "https://via.placeholder.com/554x643",
        icon: "line-icon-Drum",
        title: "Live music band",
        content: "Lorem ipsum dolor amet consectetur adipiscing"
    },
    {
        img: "https://via.placeholder.com/554x643",
        icon: "line-icon-Cocktail",
        title: "Bar and lounge",
        content: "Lorem ipsum dolor amet consectetur adipiscing"
    },
    {
        img: "https://via.placeholder.com/554x643",
        icon: "line-icon-Cauldron",
        title: "Modish foods",
        content: "Lorem ipsum dolor amet consectetur adipiscing"
    },
]

export { TextSliderData01, TextSliderData02, TextSliderData03 }