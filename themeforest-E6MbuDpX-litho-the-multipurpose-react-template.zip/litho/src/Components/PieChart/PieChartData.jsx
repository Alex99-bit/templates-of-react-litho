const PiechartData1 = [
    {
        percentage: 75,
        title: 'WEB DEVELOPMENT',
    },
    {
        percentage: 80,
        title: 'SOCIAL MARKETING',
    },
    {
        percentage: 85,
        title: 'CONTENT CREATION',
    }
]

const PiechartData2 = [
    {
        percentage: 92,
        title: 'Innovative solutions',
        content: 'Lorem ipsum is simply dummy text of the printing and type.'
    },
    {
        percentage: 90,
        title: 'Marketing strategy',
        content: 'Lorem ipsum is simply dummy text of the printing and type.'
    },
    {
        percentage: 86,
        title: 'Social Marketing',
        content: 'Lorem ipsum is simply dummy text of the printing and type.'
    }
]

export {PiechartData1, PiechartData2}